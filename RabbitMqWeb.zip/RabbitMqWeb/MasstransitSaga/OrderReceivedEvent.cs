﻿using MasstransitSaga;
using System;
using System.Collections.Generic;
using System.Text;

namespace RabbitMqWeb.Entity
{
    public class OrderReceivedEvent : Order
    {
        private readonly OrderSagaState orderSagaState;
        public OrderReceivedEvent(OrderSagaState orderSagaState)
        {
            this.orderSagaState = orderSagaState;
        }

        public Guid CorrelationId => orderSagaState.CorrelationId;
        public string ItemName => orderSagaState.ItemName;
        public decimal ItemPrice => orderSagaState.ItemPrice;
    }
}

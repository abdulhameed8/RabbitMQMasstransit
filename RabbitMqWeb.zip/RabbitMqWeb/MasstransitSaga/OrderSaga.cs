﻿using Automatonymous;
using MasstransitSaga.Configuration;
using RabbitMqWeb.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace MasstransitSaga
{
    public class OrderSaga : MassTransitStateMachine<OrderSagaState>
    {
        public State OrderArrived { get; private set; }
        public State Notification { get; private set; }

        public Event<Order> OrderMade { get; private set; }
        public Event<Customer> CustomerNotification { get; private set; }

        public OrderSaga()
        {
            InstanceState(s => s.CurrentState);

            Event(() => OrderMade,
               x =>
               {
                   x.CorrelateById(context => context.Message.CorrelationId);
                   x.OnMissingInstance(m => m.Fault());
               });

            Event(() => CustomerNotification, x =>
            {
                x.CorrelateById(context =>context.Message.CorrelationId);
                x.OnMissingInstance(m => m.Fault());
            });

            Initially(
                When(OrderMade)
                    .Then(context =>
                    {
                        context.Instance.ItemName = context.Data.ItemName;
                        context.Instance.ItemPrice = context.Data.ItemPrice;                        
                    })
                    .ThenAsync(
                        context => Console.Out.WriteLineAsync($"Order for customer {context.Data.ItemName} received"))
                    .TransitionTo(OrderArrived)
                    .Publish(context => new OrderReceivedEvent(context.Instance))

                );

            During(OrderArrived,
                When(CustomerNotification)
                    .Then(context => context.Instance.RegisteredDateTime =
                        DateTime.Now)
                    .ThenAsync(
                        context => Console.Out.WriteLineAsync($"Notification sent for customer {context.Instance.ItemName} "))
                    .Finalize()
                );

            SetCompletedWhenFinalized();
        }
    }
}

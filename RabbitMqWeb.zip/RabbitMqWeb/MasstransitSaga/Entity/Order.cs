﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RabbitMqWeb.Entity
{
    public class Order : Restaurant
    {
        
        public string ItemName { get; set; }
        public decimal ItemPrice { get; set; }
        public int Quantity { get; set; }
        public Customer customer { get; set; }
    }
}

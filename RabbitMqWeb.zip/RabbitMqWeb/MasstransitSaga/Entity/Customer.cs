﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RabbitMqWeb.Entity
{
    public class Customer
    {
        public string Name { get; set; }
        public string Mobile { get; set; }
        public Guid CorrelationId { get; set; }

    }
}

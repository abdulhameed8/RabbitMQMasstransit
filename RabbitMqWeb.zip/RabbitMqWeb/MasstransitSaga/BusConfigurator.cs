﻿using MassTransit;
using MassTransit.Saga;
using MasstransitSaga.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace MasstransitSaga
{
    public static class BusConfigurator
    {
        public static IBusControl ConfigureBus()
        {
            var saga = new OrderSaga();
            var repo = new InMemorySagaRepository<OrderSagaState>();

            return Bus.Factory.CreateUsingRabbitMq(cfg =>
            {
                var host = cfg.Host(new Uri(RabbitMqConstants.RabbitMqUri), hst =>
                {
                    hst.Username(RabbitMqConstants.UserName);
                    hst.Password(RabbitMqConstants.Password);
                });                
                cfg.ReceiveEndpoint(RabbitMqConstants.SagaQueue, e =>
                {                    
                    e.StateMachineSaga(saga, repo);                    
                    
                });

            });
        }
    }
}

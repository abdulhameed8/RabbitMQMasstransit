﻿using MassTransit;
using MassTransit.Saga;
using System;

namespace MasstransitSaga
{
    class Program
    {
        static void Main(string[] args)
        {           
            var bus = BusConfigurator.ConfigureBus();
            bus.Start();
            Console.WriteLine("Saga active.. Press enter to exit");
            Console.ReadLine();
            bus.Stop();
        }
    }
}

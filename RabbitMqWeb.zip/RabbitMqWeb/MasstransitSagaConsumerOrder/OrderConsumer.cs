﻿using MassTransit;
using RabbitMqWeb.Entity;
using System;
using System.Threading.Tasks;

namespace MasstransitSagaConsumerOrder
{
    public class OrderConsumer : IConsumer<Order>
    {
        public async Task Consume(ConsumeContext<Order> context)
        {            
            await Console.Out.WriteLineAsync($"Mastransit Message Consume for Order Processing {context.Message.ItemName} ");
            await context.Publish<Customer>(
               new { CorrelationId = context.Message.CorrelationId });
        }
    }
    
}

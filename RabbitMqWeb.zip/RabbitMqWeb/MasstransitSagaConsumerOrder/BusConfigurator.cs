﻿using MassTransit;
using MasstransitSagaConsumerOrder.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace MasstransitSagaConsumerOrder
{
    public static class BusConfigurator
    {
        public static IBusControl ConfigureBus()
        {
            return Bus.Factory.CreateUsingRabbitMq(cfg =>
            {
                var host = cfg.Host(new Uri(RabbitMqConstants.RabbitMqUri), hst =>
                {
                    hst.Username(RabbitMqConstants.UserName);
                    hst.Password(RabbitMqConstants.Password);
                });

                cfg.ReceiveEndpoint(RabbitMqConstants.OrderQueue, e =>
                {
                    e.Consumer(() => new OrderConsumer());
                });                

            });
        }
    }
}

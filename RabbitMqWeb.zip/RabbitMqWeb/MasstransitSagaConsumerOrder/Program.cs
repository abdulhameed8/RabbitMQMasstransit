﻿using MassTransit;
using System;

namespace MasstransitSagaConsumerOrder
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Masstransit Order Consumer Listening ..");
            var busControl = BusConfigurator.ConfigureBus();
            busControl.Start();
            Console.ReadKey();
            busControl.Stop();
            Console.ReadLine();
        }
    }
}

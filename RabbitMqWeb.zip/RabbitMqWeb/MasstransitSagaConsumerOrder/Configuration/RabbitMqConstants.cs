﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MasstransitSagaConsumerOrder.Configuration
{
    public static class RabbitMqConstants
    {
        public const string RabbitMqUri = "rabbitmq://localhost:5672/food/";
        public const string UserName = "guest";
        public const string Password = "guest";

        public const string OrderExchange = "masstransit.onlinefood.orderexchange";
        public const string OrderQueue = "masstransit.onlinefood.orderqueue";

        public const string NotificationExchange = "masstransit.onlinefood.customerexchange";
        public const string NotificationQueue = "masstransit.onlinefood.customerqueue";

        public const string RestaurantExchange = "masstransit.onlinefood.orderexchange";
        public const string RestaurantQueue = "masstransit.onlinefood.restaurantqueue";
    }
}

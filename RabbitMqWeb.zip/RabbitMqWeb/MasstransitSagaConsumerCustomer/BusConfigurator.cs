﻿using MassTransit;
using MasstransitSagaConsumerCustomer.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace MasstransitSagaConsumerCustomer
{
    public static class BusConfigurator
    {
        public static IBusControl ConfigureBus()
        {
            return Bus.Factory.CreateUsingRabbitMq(cfg =>
            {
                var host = cfg.Host(new Uri(RabbitMqConstants.RabbitMqUri), hst =>
                {
                    hst.Username(RabbitMqConstants.UserName);
                    hst.Password(RabbitMqConstants.Password);
                });

                cfg.ReceiveEndpoint(RabbitMqConstants.NotificationQueue, e =>
                {
                    e.Consumer(() => new CustomerConsumer());
                });                

            });
        }
    }
}

﻿using MassTransit;
using System;

namespace MasstransitSagaConsumerCustomer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Masstransit Customer Consumer Listening ..");
            var busControl = BusConfigurator.ConfigureBus();
            busControl.Start();
            Console.ReadKey();
            busControl.Stop();
            Console.ReadLine();
        }
    }
}

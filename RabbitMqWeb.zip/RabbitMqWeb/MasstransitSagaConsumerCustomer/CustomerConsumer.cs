﻿using MassTransit;
using RabbitMqWeb.Entity;
using System;
using System.Threading.Tasks;

namespace MasstransitSagaConsumerCustomer
{
    public class CustomerConsumer : IConsumer<Customer>
    {
        public async Task Consume(ConsumeContext<Customer> context)
        {            
            await Console.Out.WriteLineAsync($"Mastransit Message Consume for Customer Processing {context.Message.CorrelationId} ");
        }
    }
    
}

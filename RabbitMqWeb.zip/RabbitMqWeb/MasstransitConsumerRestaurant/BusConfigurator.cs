﻿using MassTransit;
using MasstransitConsumerRestaurant.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace MasstransitConsumerRestaurant
{
    public static class BusConfigurator
    {
        public static IBusControl ConfigureBus()
        {
            return Bus.Factory.CreateUsingRabbitMq(cfg =>
            {
                var host = cfg.Host(new Uri(RabbitMqConstants.RabbitMqUri), hst =>
                {
                    hst.Username(RabbitMqConstants.UserName);
                    hst.Password(RabbitMqConstants.Password);
                });

                cfg.ReceiveEndpoint(RabbitMqConstants.RestaurantQueue, e =>
                {
                    e.Consumer(() => new RestaurantConsumer());
                });                

            });
        }
    }
}

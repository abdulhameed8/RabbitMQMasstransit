﻿using MassTransit;
using RabbitMqWeb.Entity;
using System;
using System.Threading.Tasks;

namespace MasstransitConsumerRestaurant
{
    public class RestaurantConsumer : IConsumer<Restaurant>
    {
        public async Task Consume(ConsumeContext<Restaurant> context)
        {            
            await Console.Out.WriteLineAsync($"Mastransit Message Consume for Restaurant Processing {context.Message.Name} ");
        }
    }
    
}

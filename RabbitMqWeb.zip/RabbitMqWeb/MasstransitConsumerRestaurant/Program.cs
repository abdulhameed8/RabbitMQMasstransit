﻿using MassTransit;
using System;

namespace MasstransitConsumerRestaurant
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Masstransit Consumer Listening for restuarant order..");
            var busControl = BusConfigurator.ConfigureBus();
            busControl.Start();
            Console.ReadKey();
            busControl.Stop();
            Console.ReadLine();
        }
    }
}

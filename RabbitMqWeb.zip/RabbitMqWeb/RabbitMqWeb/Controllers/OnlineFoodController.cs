﻿using Microsoft.AspNetCore.Mvc;
using RabbitMqWeb.Contract;
using RabbitMqWeb.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RabbitMqWeb.Controllers
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/onlinefood")]
    public class OnlineFoodController : ControllerBase
    {
        private readonly IMessageBroker<Order> _messageBroker;
        public OnlineFoodController(IMessageBroker<Order> messageBroker)
        {
            _messageBroker = messageBroker;
        }

        [HttpPost]
        public ActionResult Add([FromBody] Order order)
        {
            _messageBroker.Publish(order);
            return Ok("Order Added Successfully");
        }

        [HttpGet]
        public ActionResult Get()
        {            
            return Ok("Success");
        }

        [HttpGet("orderdetails")]
        public ActionResult GetOrderDetails()
        {
            Thread.Sleep(60000);
            throw new NullReferenceException("Object Reference Error");
            return Ok("ordersuccessfull");
        }
    }
}

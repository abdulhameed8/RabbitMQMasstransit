﻿using RabbitMqWeb.Contract;
using RabbitMqWeb.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RabbitMQ.Client;
using RabbitMqWeb.Configuration;
using Newtonsoft.Json;
using System.Text;
using RabbitMqWeb.Configuration.Rabbitmq;

namespace RabbitMqWeb.Manager
{
    public class RabbitMqManager : IMessageBroker<Order>,IDisposable
    {
        private readonly IModel channel;

        public RabbitMqManager()
        {
            var connectionFactory = new ConnectionFactory { Uri = new Uri(RabbitMqConstants.RabbitMqUri) };
            var connection = connectionFactory.CreateConnection(); // Create Connection
            channel = connection.CreateModel(); // Create Channels            
        }

        public void Dispose() // Dispose the channel after used
        {
            if (!channel.IsClosed)
                channel.Close();
        }

        public void Publish(Order messageInfo) // Generic Method Publish Message
        {
            PublishOrder(messageInfo); // Publish Order
            //NotifyCustomer(messageInfo.customer);
        }


        private void NotifyCustomer(Customer customer)
        {
            // Define Exchange Properties
            channel.ExchangeDeclare(
                exchange: RabbitMqConstants.NotificationExchange,
                type: ExchangeType.Fanout);

            // Define Queue Properties
            // durable : the queue will survive a broker restart
            //exclusive : (used by only one connection and the queue will be deleted when that connection closes)
            //autoDelete: queue that has had at least one consumer is deleted when last consumer unsubscribes
            //arguments (optional; used by plugins and broker-specific features such as message autoexpire, max length etc)
            channel.QueueDeclare(
                queue: RabbitMqConstants.NotificationQueue,
                durable: false, exclusive: false, 
                autoDelete: false, arguments: null);

            // Define Binding 
            channel.QueueBind(
                queue: RabbitMqConstants.NotificationQueue,
                exchange: RabbitMqConstants.NotificationExchange,
                routingKey: "");

            var serializedMessage = JsonConvert.SerializeObject(customer);

            var messageProperties = channel.CreateBasicProperties(); // Create empty message properties
            messageProperties.ContentType = RabbitMqConstants.JsonMimeType; // Setting content type of message but there are other more options like setting header, set message expiration etc
            
            // Publish Message
            channel.BasicPublish(
                exchange: RabbitMqConstants.NotificationExchange,
                routingKey: "",
                basicProperties: messageProperties,
                body: Encoding.UTF8.GetBytes(serializedMessage));
        }

        private void PublishOrder(Order messageInfo)
        {
            // Queues Properties
            channel.ExchangeDeclare(
                exchange: RabbitMqConstants.OrderExchange,
                type: ExchangeType.Fanout);
            // Define Queue Properties
            // durable : the queue will survive a broker restart
            //exclusive : (used by only one connection and the queue will be deleted when that connection closes)
            //autoDelete: queue that has had at least one consumer is deleted when last consumer unsubscribes
            //arguments (optional; used by plugins and broker-specific features such as message autoexpire, max length etc)
            channel.QueueDeclare(
                queue: RabbitMqConstants.OrderQueue,
                durable: false, exclusive: false,
                autoDelete: false, arguments: null);

            channel.QueueBind(
                queue: RabbitMqConstants.OrderQueue,
                exchange: RabbitMqConstants.OrderExchange,
                routingKey: "");

            var serializedMessage = JsonConvert.SerializeObject(messageInfo);

            var messageProperties = channel.CreateBasicProperties(); // Create empty message properties
            messageProperties.ContentType = RabbitMqConstants.JsonMimeType; // Setting content type of message but there are other more options like setting header, set message expiration etc

            channel.BasicPublish(
                exchange: RabbitMqConstants.OrderExchange,
                routingKey: "",
                basicProperties: messageProperties, // you can addtinal message properties like priority,correlation_id etc
                body: Encoding.UTF8.GetBytes(serializedMessage));
        }
    }
}

﻿using MassTransit;
using RabbitMqWeb.Configuration.Masstransit;
using RabbitMqWeb.Contract;
using RabbitMqWeb.Entity;
using RabbitMqWeb.Manager.Masstransit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RabbitMqWeb.Manager
{
    public class MasstransitManager : IMessageBroker<Order>
    {
        private readonly ISendEndpoint endPoint; 
        public MasstransitManager()
        {
            var bus = BusConfigurator.ConfigureBus();
            var sendToUri = new Uri($"{RabbitMqConstants.RabbitMqUri}{RabbitMqConstants.OrderExchange}");            
            endPoint = bus.GetSendEndpoint(sendToUri).Result;
        }

        public void Publish(Order messageInfo)
        {
            try
            {
                endPoint.Send<Order>(messageInfo).Wait();
            }
            catch (Exception ex)
            {

            }
            
            
        }
    }
}

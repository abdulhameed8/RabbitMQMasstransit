﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RabbitMqWeb.Contract
{
    public interface IMessageBroker<T> where T : class
    {
        void Publish(T messageInfo);        
    }
}

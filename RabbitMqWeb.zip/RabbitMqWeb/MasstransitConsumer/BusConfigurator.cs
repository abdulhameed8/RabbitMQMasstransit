﻿using GreenPipes;
using MassTransit;
using MasstransitConsumer.Configuration;
using MasstransitConsumer.CustomMiddleware;
using System;
using System.Collections.Generic;
using System.Text;

namespace MasstransitConsumer
{
    public static class BusConfigurator
    {
        public static IBusControl ConfigureBus()
        {
            return Bus.Factory.CreateUsingRabbitMq(cfg =>
            {
                var host = cfg.Host(new Uri(RabbitMqConstants.RabbitMqUri), hst =>
                {
                    hst.Username(RabbitMqConstants.UserName);
                    hst.Password(RabbitMqConstants.Password);
                });

                cfg.UseExceptionLogger();

                cfg.ReceiveEndpoint(RabbitMqConstants.OrderQueue, e =>
                {

                    
                    e.UseMessageRetry(r =>
                    {
                        r.Interval(3, 5000);
                        r.Ignore<NullReferenceException>();
                        r.Ignore<ArgumentException>();
                    });//other option exponential, icremental

                    e.UseCircuitBreaker(cb =>
                    {
                        cb.TrackingPeriod = TimeSpan.FromMinutes(1); //window time before the success/failure counts are reset to zero
                        cb.TripThreshold = 15; // ratio of successful to failed attempts.
                        cb.ActiveThreshold = 4; //This is the number of messages that must reach the circuit breaker in a tracking period before the circuit breaker can trip
                        cb.ResetInterval = TimeSpan.FromMinutes(6); // The period of time between the circuit breaker trip and the first attempt to close the circuit breaker
                    });

                    //e.Consumer(() => new OrderConsumer());
                    //e.Consumer<OrderConsumer>(c => c.UseExceptionLogger());
                    e.Consumer<OrderConsumer>();
                });                

            });
        }
    }
}

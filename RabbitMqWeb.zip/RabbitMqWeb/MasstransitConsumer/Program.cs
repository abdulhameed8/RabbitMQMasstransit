﻿using MassTransit;
using MassTransit.RabbitMqTransport;
using System;


namespace MasstransitConsumer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Masstransit Consumer Listening for food order..");
            var busControl = BusConfigurator.ConfigureBus();
            busControl.Start();
            Console.ReadKey();
            busControl.Stop();
            Console.ReadLine();

        }
    }
}

﻿using GreenPipes;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MasstransitConsumer.CustomMiddleware
{
    public class ExceptionLoggerFilter<T> :
    IFilter<T>
    where T : class, PipeContext
    {
        long _exceptionCount;
        long _successCount;
        long _attemptCount;

        public void Probe(ProbeContext context) // Manipulate Probe Context // name value collection that travel to pipeline
        {
            var scope = context.CreateFilterScope("exceptionLogger");
            scope.Add("attempted", _attemptCount);
            scope.Add("succeeded", _successCount);
            scope.Add("faulted", _exceptionCount);            
        }

        /// <summary>
        /// Send is called for each context that is sent through the pipeline
        /// </summary>
        /// <param name="context">The context sent through the pipeline</param>
        /// <param name="next">The next filter in the pipe, must be called or the pipe ends here</param>
        // This method execute the middleware 
        // First argument related to current context in pipe second argument represent second piece of middleware in the pipeline
        public async Task Send(T context, IPipe<T> next) 
        {
            try
            {
                Interlocked.Increment(ref _attemptCount);

                // here the next filter in the pipe is called
                await next.Send(context);

                Interlocked.Increment(ref _successCount);
            }
            catch (Exception ex)
            {
                Interlocked.Increment(ref _exceptionCount);

                await Console.Out.WriteLineAsync($"An exception occurred: {ex.Message}");

                // propagate the exception up the call stack
                throw;
            }
        }
    }
}

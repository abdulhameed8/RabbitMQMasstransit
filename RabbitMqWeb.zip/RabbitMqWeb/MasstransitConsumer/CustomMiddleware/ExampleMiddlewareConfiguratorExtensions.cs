﻿using GreenPipes;
using System;
using System.Collections.Generic;
using System.Text;

namespace MasstransitConsumer.CustomMiddleware
{
    public static class ExampleMiddlewareConfiguratorExtensions
    {
        // create extension method for all configurator object, convention is start with word Use
        public static void UseExceptionLogger<T>(this IPipeConfigurator<T> configurator)
            where T : class, PipeContext
        {
            // This add specification to the object
            configurator.AddPipeSpecification(new ExceptionLoggerSpecification<T>());
        }
    }
}

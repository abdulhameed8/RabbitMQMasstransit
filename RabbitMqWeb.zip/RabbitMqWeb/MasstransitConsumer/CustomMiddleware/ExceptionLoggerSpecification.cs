﻿using GreenPipes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasstransitConsumer.CustomMiddleware
{
    public class ExceptionLoggerSpecification<T> :
    IPipeSpecification<T>
    where T : class, PipeContext
    {
        // This is called before execution of middleware it returns colllection of validation result
        public IEnumerable<ValidationResult> Validate()
        {
            return Enumerable.Empty<ValidationResult>();
        }
        // Method apply, applies filter to the pipeline
        public void Apply(IPipeBuilder<T> builder)
        {           
            builder.AddFilter(new ExceptionLoggerFilter<T>());
        }
    }
}

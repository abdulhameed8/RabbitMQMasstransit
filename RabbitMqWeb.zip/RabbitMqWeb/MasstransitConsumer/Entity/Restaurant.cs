﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RabbitMqWeb.Entity
{
    public class Restaurant
    {
        public string Name { get; set; }
    }
}

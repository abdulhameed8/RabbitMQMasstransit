﻿using MassTransit;
using RabbitMqWeb.Entity;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace MasstransitConsumer
{
    public class OrderConsumer : IConsumer<Order>
    {
        public async Task Consume(ConsumeContext<Order> context)
        {
            //throw new IndexOutOfRangeException("An Custom Error");
            //throw new ArgumentException("An Custom Error");
            await Console.Out.WriteLineAsync($"Mastransit Message Consume for Order Processing {context.Message.ItemName} ");
            var client = new HttpClient();
            var result = await client.GetAsync("http://localhost:5000/api/onlinefood/orderdetails");

            if (result.StatusCode != System.Net.HttpStatusCode.OK)
                throw new HttpRequestException("Error Calling Service");
        }
    }
    
}

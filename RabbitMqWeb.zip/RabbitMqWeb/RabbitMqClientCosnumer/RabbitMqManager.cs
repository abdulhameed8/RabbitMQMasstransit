﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RabbitMqClientCosnumer.Configuration;
using RabbitMqClientCosnumer.Entity;

namespace RabbitMqClientCosnumer
{
    public class RabbitMqManager : IDisposable
    {
        private readonly IModel channel;

        public RabbitMqManager()
        {
            var connectionFactory = new ConnectionFactory { Uri = new Uri(RabbitMqConstants.RabbitMqUri) };
            var connection = connectionFactory.CreateConnection();
            channel = connection.CreateModel();            
        }

        public void ListenForOrder()
        {
            #region queue and qos setup
            // durable : the queue will survive a broker restart
            //exclusive : (used by only one connection and the queue will be deleted when that connection closes)
            //autoDelete: queue that has had at least one consumer is deleted when last consumer unsubscribes
            //arguments (optional; used by plugins and broker-specific features such as message autoexpire, max length etc)
            channel.QueueDeclare(
                queue: RabbitMqConstants.OrderQueue,
                durable: false, exclusive: false,
                autoDelete: false, arguments: null);
            // Not to give more than one message at a time to a consumer
            // Using this it allows multiple message consume in one go
            // Prefetch size set total maximum size of all message default 0 means no limit
            // global false to set these properties only available to this channel not global
            channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false); 
            #endregion
            var eventingConsumer = new EventingBasicConsumer(channel);
            eventingConsumer.Received += (chan, eventArgs) =>
            {
                var contentType = eventArgs.BasicProperties.ContentType;
                if (contentType != RabbitMqConstants.JsonMimeType)
                    throw new ArgumentException(
                        $"Can't handle content type {contentType}");

                var body = eventArgs.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);
                var orderConsumer = new OrderConsumer();
                var commandObj =
                JsonConvert.DeserializeObject<Order>(message);
                orderConsumer.Consume(commandObj);
                // When Message process successfully now send acknowldgement to Rabbitmq passing unqie delivery tag got as parameter
                channel.BasicAck(deliveryTag: eventArgs.DeliveryTag,
                    multiple: false);
            };
            channel.BasicConsume(
                queue: RabbitMqConstants.OrderQueue,
                autoAck: false,
                consumer: eventingConsumer);
        }

        public void Dispose() // dispose channel 
        {
            if (!channel.IsClosed)
                channel.Close();
        }
    }
}

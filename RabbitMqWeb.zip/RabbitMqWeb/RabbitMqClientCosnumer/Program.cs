﻿using System;

namespace RabbitMqClientCosnumer
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var rabbitMqManager = new RabbitMqManager())
            {
                rabbitMqManager.ListenForOrder();
                Console.WriteLine("Rabbitmq Consumer Listening for Food Order..");
                Console.ReadKey();
            }
        }
    }
}

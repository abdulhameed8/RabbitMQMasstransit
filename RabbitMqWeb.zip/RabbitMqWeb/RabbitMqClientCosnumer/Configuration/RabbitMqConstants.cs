﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RabbitMqClientCosnumer.Configuration
{
    public static class RabbitMqConstants
    {
        public const string RabbitMqUri = "amqp://guest:guest@localhost:5672/food";
        public const string JsonMimeType ="application/json";
        public const string UserName = "guest";
        public const string Password = "guest";

        public const string OrderExchange = "onlinefood.orderexchange";
        public const string OrderQueue = "onlinefood.orderqueue";

        public const string NotificationExchange = "onlinefood.customerexchange";
        public const string NotificationQueue = "onlinefood.customerqueue";

        public const string RestaurantExchange = "onlinefood.restaurantexchange";
        public const string RestaurantQueue = "onlinefood.restaurantqueue";
    }
}

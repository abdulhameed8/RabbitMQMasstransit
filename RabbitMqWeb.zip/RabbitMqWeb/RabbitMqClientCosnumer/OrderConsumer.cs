﻿using RabbitMqClientCosnumer.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace RabbitMqClientCosnumer
{
    public class OrderConsumer
    {
        public void Consume(Order order)
        {            
            Console.WriteLine($"Rabbitmq Message Consume for Order Processing {order.ItemName} ");
        }
    }
}

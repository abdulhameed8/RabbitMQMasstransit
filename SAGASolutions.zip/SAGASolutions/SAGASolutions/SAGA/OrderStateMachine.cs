﻿using Automatonymous;
using SAGASolutions.Configuration;
using SAGASolutions.Message;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAGASolutions.SAGA
{
    public class OrderStateMachine : MassTransitStateMachine<OrderState>
    {
        // States
        public State Submitted { get; private set; }
        public State Accepted { get; private set; }

        // Events
        public Event<ISubmitOrder> SubmitOrder { get; private set; }
        public Event<IOrderAccepted> OrderAccepted { get; private set; }

        public OrderStateMachine()
        {
            // States Intializations

            InstanceState(x => x.CurrentState, Submitted, Accepted);

            // Events Definations

            Event(() => SubmitOrder, x => 
            {
                x.CorrelateById(context => context.Message.OrderId);
                x.OnMissingInstance(m => m.Discard());
            });
            Event(() => OrderAccepted, x => 
            {
                x.CorrelateById(context => context.Message.OrderId);
                x.OnMissingInstance(m => m.Discard());
            });            


            // Behaviours Orchestrations Workflows         

            Initially(
            When(SubmitOrder)
                .TransitionTo(Submitted) 
                .Send(new Uri($"{RabbitMqConstants.RabbitMqUri}{RabbitMqConstants.OrderQueue}"),context => new SubmitOrderRecievedEvent(context.Data.OrderId, context.Data.OrderName))                
                .ThenAsync(context => Console.Out.WriteLineAsync($"Airline Request {context.Data.OrderId} Submitted, Destination Name {context.Data.OrderName}"))
                );

            During(Submitted,
                When(OrderAccepted)
                .TransitionTo(Accepted)                 
                    .Send(new Uri($"{RabbitMqConstants.RabbitMqUri}{RabbitMqConstants.AcceptOrderQueue}"), context => new AcceptOrderRecievedEvent(context.Data.OrderId, context.Data.OrderName))                    
                    .ThenAsync(context => Console.Out.WriteLineAsync($"Airline Request {context.Data.OrderId} Accepted, Destination Name {context.Data.OrderName}"))
                    .Finalize()
                    );

            During(Accepted,
                Ignore(SubmitOrder));

            SetCompletedWhenFinalized();
        }
    }
}



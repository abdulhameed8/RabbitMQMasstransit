﻿using Automatonymous;
using MassTransit;
using MassTransit.Saga;
using SAGASolutions.Configuration;
using SAGASolutions.Consumer;
using SAGASolutions.SAGA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAGASolutions
{
    public static class BusConfigurator
    {
        public static IBusControl ConfigureBus()
        {
            var saga = new OrderStateMachine();
            var repo = new InMemorySagaRepository<OrderState>();            

            return Bus.Factory.CreateUsingRabbitMq(cfg =>
            {
                var host = cfg.Host(new Uri(RabbitMqConstants.RabbitMqUri), hst =>
                {
                    hst.Username(RabbitMqConstants.UserName);
                    hst.Password(RabbitMqConstants.Password);
                });
                cfg.ReceiveEndpoint(RabbitMqConstants.SagaQueue, e =>
                {
                    e.StateMachineSaga(saga, repo);                    
                });
                cfg.ReceiveEndpoint(RabbitMqConstants.OrderQueue, e =>
                {                    
                    e.Consumer(() => new SubmitOrderConsumer());
                });
                cfg.ReceiveEndpoint(RabbitMqConstants.AcceptOrderQueue, e =>
                {                    
                    e.Consumer(() => new AcceptOrderConsumer());
                });


            });
        }
    }
}

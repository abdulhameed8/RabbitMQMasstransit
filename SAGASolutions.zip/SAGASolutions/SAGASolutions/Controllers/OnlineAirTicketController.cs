﻿using Microsoft.AspNetCore.Mvc;
using SAGASolutions.Message;
using SAGASolutions.Publisher;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAGASolutions.Controllers
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/onlineairticket")]
    public class OnlineAirTicketController : ControllerBase
    {
        private readonly IMessageBroker _messageBroker;
        public OnlineAirTicketController(IMessageBroker messageBroker)
        {
            _messageBroker = messageBroker;
        }

        [HttpPost]
        public ActionResult Post([FromBody] SubmitOrder order)
        {
            _messageBroker.SubmitOrder(order);
            return Ok("Airline Order Submitted Successfully");
        }

        [HttpPost("acceptorder")]
        public ActionResult AcceptOrder([FromBody] OrderAccepted order)
        {
            _messageBroker.AcceptOrder(order);
            return Ok("Airline Order Accepted Successfully");
        }

        [HttpGet]
        public ActionResult Get()
        {
            return Ok("Success");
        }

       
    }
}

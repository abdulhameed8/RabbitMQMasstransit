﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MassTransit;
using SAGASolutions.Configuration;
using SAGASolutions.Message;

namespace SAGASolutions.Publisher
{
    public class MasstransitManager : IMessageBroker
    {        
        private readonly IBusControl bus;
        private readonly ISendEndpoint endPoint;
        public MasstransitManager()
        {
            bus = BusConfigurator.ConfigureBus();
            var sendToUri = new Uri($"{RabbitMqConstants.RabbitMqUri}{RabbitMqConstants.SagaQueue}");
            endPoint = bus.GetSendEndpoint(sendToUri).Result;
        }

        public void SubmitOrder(SubmitOrder submitOrder)
        {
            endPoint.Send<SubmitOrder>(submitOrder).Wait();
        }

        public void AcceptOrder(OrderAccepted orderAccepted)
        {           
            endPoint.Send<OrderAccepted>(orderAccepted).Wait();
        }
    }
}

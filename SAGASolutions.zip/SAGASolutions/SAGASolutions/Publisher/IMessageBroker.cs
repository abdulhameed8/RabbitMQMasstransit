﻿using SAGASolutions.Message;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAGASolutions.Publisher
{
    public interface IMessageBroker
    {
        void SubmitOrder(SubmitOrder submitOrder );
        void AcceptOrder(OrderAccepted orderAccepted);
    }
}

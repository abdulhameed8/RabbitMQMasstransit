﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAGASolutions.Message
{
    public interface IOrderAccepted
    {
        string OrderName { get; set; }
        Guid OrderId { get;set; }        
    }
}

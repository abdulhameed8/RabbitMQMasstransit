﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAGASolutions.Message
{
    public interface ISubmitOrder
    {
        string OrderName { get; set; }
        Guid OrderId { get; }        
    }
}

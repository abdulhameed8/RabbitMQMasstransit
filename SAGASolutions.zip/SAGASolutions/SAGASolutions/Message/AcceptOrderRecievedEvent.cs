﻿using SAGASolutions.SAGA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAGASolutions.Message
{
    public class AcceptOrderRecievedEvent : OrderAccepted
    {
        
        public AcceptOrderRecievedEvent(Guid orderId, string orderName)
        {
            OrderId = orderId;
            OrderName = orderName;
        }
        public Guid OrderId { get; }
        public string OrderName { get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAGASolutions.Configuration
{
    public static class RabbitMqConstants
    {
        public const string RabbitMqUri = "rabbitmq://localhost:5672/airline/";
        public const string UserName = "guest";
        public const string Password = "guest";
        public const string SagaQueue = "masstransit.airline.sagaqueue";
        public const string OrderQueue = "masstransit.airline.orderqueue";
        public const string AcceptOrderQueue = "masstransit.airline.acceptorderqueue";
    }
}

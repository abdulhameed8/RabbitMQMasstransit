﻿using MassTransit;
using SAGASolutions.Message;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAGASolutions.Consumer
{
    public class SubmitOrderConsumer : IConsumer<SubmitOrderRecievedEvent>
    {
        public async Task Consume(ConsumeContext<SubmitOrderRecievedEvent> context)
        {
            await Console.Out.WriteLineAsync($"Consumer ISubmitOrder OrderId {context.Message.OrderId} OrderName {context.Message.OrderName}");
        }
    }
}

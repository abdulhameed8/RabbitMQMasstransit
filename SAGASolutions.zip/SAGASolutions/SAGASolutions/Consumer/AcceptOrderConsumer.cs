﻿using MassTransit;
using SAGASolutions.Message;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAGASolutions.Consumer
{
    public class AcceptOrderConsumer : IConsumer<AcceptOrderRecievedEvent>
    {
        public async Task Consume(ConsumeContext<AcceptOrderRecievedEvent> context)
        {
            await Console.Out.WriteLineAsync($"Consumer IOrderAccepted OrderId {context.Message.OrderId} OrderName {context.Message.OrderName}");
        }
    }
}
